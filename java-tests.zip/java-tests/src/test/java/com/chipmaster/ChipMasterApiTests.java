package com.chipmaster;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class ChipMasterApiTests {

    @BeforeAll
    public static void setup() {
        RestAssured.baseURI = "http://localhost";
        RestAssured.port = 3060;
    }

    @Test public void testHomeLoads() {
        get("/home").then().statusCode(200);
    }
    @Test public void testProductsLoads() {
        get("/products").then().statusCode(200);
    }
    @Test public void testProductDetails() {
        get("/product/1").then().statusCode(200);
    }
    @Test public void testCartWithoutLogin() {
        get("/cart").then().statusCode(200);
    }
    @Test public void testCheckoutRequiresLogin() {
        get("/checkout").then().statusCode(200);
    }
    @Test public void testLoginInvalid() {
        given().formParam("email", "foo@bar.com").formParam("password", "wrong")
               .post("/login").then().statusCode(anyOf(equalTo(200), equalTo(302)));
    }
    @Test public void testForgotPasswordPage() {
        get("/forgotpassword").then().statusCode(200);
    }
    @Test public void testResetPasswordInvalidToken() {
        get("/reset_password/invalid-token").then().statusCode(200);
    }
    @Test public void testProfileRequiresLogin() {
        get("/profile").then().statusCode(200);
    }
    @Test public void testRegisterPage() {
        get("/register").then().statusCode(200);
    }
    @Test public void testWishlistRequiresLogin() {
        get("/wishlist").then().statusCode(200);
    }
    @Test public void testOrdersRequiresLogin() {
        get("/orders").then().statusCode(200);
    }
    @Test public void testAddCartUnauth() {
        post("/api/cart/add/1").then().statusCode(200).body("success", equalTo(true));
    }
    @Test public void testInvalidOrderPlace() {
        given().contentType(ContentType.JSON).body("{}")
               .post("/api/place-order").then().statusCode(anyOf(equalTo(200), equalTo(302)));
    }
    @Test public void testOrderSuccessRequiresLogin() {
        get("/order-success/1").then().statusCode(200);
    }
    @Test public void testCancelOrderUnauthorized() {
        post("/api/orders/1/cancel").then().statusCode(anyOf(equalTo(400), equalTo(403), equalTo(302), equalTo(200)));
    }
    @Test public void testSearchHomeKeyword() {
        get("/products?search=Ryzen").then().statusCode(200);
    }
    @Test public void testSortByPrice() {
        get("/products?sort_by=price_asc").then().statusCode(200);
    }
    @Test public void testSortByPopularity() {
        get("/products?sort_by=popularity").then().statusCode(200);
    }
    @Test public void testAddAddressRequiresLogin() {
        given().formParam("full_name","A").post("/add_address").then().statusCode(302);
    }
    @Test public void testAddCardRequiresLogin() {
        given().formParam("card_holder","A").post("/add_card").then().statusCode(302);
    }
    @Test public void testChangePasswordRequiresLogin() {
        given().formParam("current_password","a").post("/change_password").then().statusCode(302);
    }
    @Test public void testDeleteAccountRequiresLogin() {
        given().formParam("password","a").post("/delete_account").then().statusCode(302);
    }
    @Test public void testRateEndpointUnauth() {
        given().contentType(ContentType.JSON).body("{'rating':5,'comment':'test'}")
               .post("/api/reviews/1").then().statusCode(200).body("success", equalTo(false));
    }
    @Test public void testGetCartUnauth() {
        get("/cart").then().statusCode(200);
    }
} 